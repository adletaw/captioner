#' captioner: A package for numbering figures and generating captions
#'
#' @author Alathea D Letaw, \email{alathea@@zoology.ubc.ca}
#' 